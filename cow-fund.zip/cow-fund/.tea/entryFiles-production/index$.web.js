require('@alipay/appx-compiler/lib/sjsEnvInit');
require('./config$');
require('../../components/card/card');
require('../../components/fund/fund');
require('../../components/line/index');
require('../../components/trend/trend');
require('../../pages/index/index');
